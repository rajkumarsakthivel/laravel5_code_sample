<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Product;
use Session;

class ProductController extends Controller
{
     public function index(){
        //fetch all products data
        $products = Product::orderBy('created_at','desc')->get();
        
        //pass Products data to view and load list view
        return view('product.index', ['products' => $products]);
    }
    
    public function details($id){
        //fetch Product data
        $product = Product::find($id);
        
        //pass Products data to view and load list view
        return view('product.details', ['product' => $product]);
    }
    
    public function add(){
        //load form view
        return view('product.add');
    }
    
    public function insert(Request $request){
        //validate Product data
        $this->validate($request, [
            'code'          => 'required',
            'name'          => 'required',
            'cost_price'    => 'required',
            'sale_price'    => 'required',
            'status'        => 'required'
        ]);
        
        //get Product data
        $productData = $request->all();
        
        //insert Product data
        Product::create($productData);
        
        //store status message
        Session::flash('success_msg', 'Product added successfully!');

        return redirect()->route('product.index');
    }
    
    public function edit($id){
        //get Product data by id
        $product = Product::find($id);
        
        //load form view
        return view('product.edit', ['product' => $product]);
    }
    
    public function update($id, Request $request){
        //validate Product data
        $this->validate($request, [
            'code'          => 'required',
            'name'          => 'required',
            'cost_price'    => 'required',
            'sale_price'    => 'required',
            'status'        => 'required'
        ]);
        
        //get Product data
        $productData = $request->all();
        
        //update Product data
        Product::find($id)->update($productData);
        
        //store status message
        Session::flash('success_msg', 'Product updated successfully!');

        return redirect()->route('product.index');
    }
    
    public function delete($id){
        //update Product data
        Product::find($id)->delete();
        
        //store status message
        Session::flash('success_msg', 'Product deleted successfully!');

        return redirect()->route('product.index');
    }



}
