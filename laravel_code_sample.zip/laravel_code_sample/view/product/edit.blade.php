@extends('layouts.app')

@section('content')
<div class="container">
<div class="row">
    <div class="col-md-12">
        @if($errors->any())
            <div class="alert alert-danger">
            @foreach($errors->all() as $error)
                <p>{{ $error }}</p>
            @endforeach()
            </div>
        @endif
        <div class="panel panel-default">
            <div class="panel-heading">
                Edit Product <a href="{{ route('product.index') }}" class="label label-primary pull-right">Back</a>
            </div>
            <div class="panel-body">
                <form action="{{ route('product.update', $product->id) }}" method="POST" class="form-horizontal">
                    {{ csrf_field() }}
                    <div class="form-group">
                        <label class="control-label col-sm-2" >Code</label>
                        <div class="col-sm-6">
                            <input type="text" name="code" id="code" class="form-control" value="{{ old( 'code', $product->code) }}">
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="control-label col-sm-2" >Name</label>
                        <div class="col-sm-6">
                            <input type="text" name="name" id="name" class="form-control" value="{{ old( 'name', $product->name) }}">
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="control-label col-sm-2" >Cost Price</label>
                        <div class="col-sm-6">
                            <input type="text" name="cost_price" id="cost_price" class="form-control" value="{{ old( 'cost_price', $product->cost_price) }}">
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="control-label col-sm-2" >Sale Price</label>
                        <div class="col-sm-6">
                            <input type="text" name="sale_price" id="sale_price" class="form-control"  value="{{ old( 'sale_price', $product->sale_price) }}">
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="control-label col-sm-2" >Status</label>
                        <div class="col-sm-3">
                            <select name="status" class="form-control">
                            <option value="">select</option>
                            <option value="1" <?php if ( $product->status == 1 ) { ?> selected <?php } ?> > Enabled
                            </option>
                            <option value="0"  <?php if ( $product->status == 0 ) { ?> selected <?php } ?> > Disabled
                            </option>
                            </select>
                        </div>
                    </div>
                    <div class="form-group">
                        <div class="col-sm-offset-2 col-sm-10">
                            <input type="submit" class="btn btn-default" value="Update Product" />
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
</div>
@endsection