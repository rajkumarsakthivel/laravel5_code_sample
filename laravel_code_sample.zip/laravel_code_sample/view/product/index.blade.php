@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row">
        <div class="col-md-12">
            <div class="panel panel-default">
                <div class="panel-heading">Product List</div>
                <div class="panel-body">
    <div class="col-md-12">
        @if(Session::has('success_msg'))
        <div class="alert alert-success">{{ Session::get('success_msg') }}</div>
        @endif
    <!-- Posts list -->
    @if(!empty($products))
        <div class="row">
            <div class="col-md-12">
            <div class="pull-left">
                    <h3>&nbsp;</h3>
                </div>
                <div class="pull-right">
                    <a class="btn btn-success" href="{{ route('product.add') }}"> Add New</a>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-xs-12 col-sm-12 col-md-12">
                <table class="table table-bordered task-hover">
                    <!-- Table Headings -->
                    <thead>
                        <th>Code</th>
                        <th>Name</th>
                        <th>Cost Price</th>
                        <th>Sale Price</th>
                        <th>Action</th>
                    </thead>
    
                    <!-- Table Body -->
                    <tbody>
                    @if(count($products) >0)
                    @foreach($products as $product)
                        <tr>
                            <td class="table-text">
                                <div>{{$product->code}}</div>
                            </td>
                            <td class="table-text">
                                <div>{{ucfirst($product->name)}}</div>
                            </td>
                            <td class="table-text">
                                <div>£{{$product->cost_price}}</div>
                            </td>
                                <td class="table-text">
                                <div>£{{$product->sale_price}}</div>
                            </td>
                            <td>
                                <a href="{{ route('product.details', $product->id) }}" class="label label-success">Details</a>
                                <a href="{{ route('product.edit', $product->id) }}" class="label label-warning">Edit</a>
                                <a href="{{ route('product.delete', $product->id) }}" class="label label-danger" onclick="return confirm('Are you sure to delete?')">Delete</a>
                            </td>
                        </tr>
                    @endforeach
                    @else
                    <tr>
                            <td class="table-text" colspan="5">
                                <div><center>No Records Found</center></div>
                            </td>
                    </tr>
                    @endif        
                    </tbody>
                </table>
            </div>
        </div>
    @endif
    </div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
@endsection