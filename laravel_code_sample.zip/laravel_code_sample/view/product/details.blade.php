@extends('layouts.app')
@section('content')
<div class="container">
<div class="row">
    <div class="col-md-12">
        <div class="panel panel-default">
            <div class="panel-heading">
                Product Details <a href="{{ route('product.index') }}" class="label label-primary pull-right">Back</a>
            </div>
            <div class="panel-body">
                <div class="col-xs-12 col-sm-12 col-md-12">
        <div class="form-group">
            <strong>Code:</strong>
            {{ $product->code }}
        </div>
    </div>
    <div class="col-xs-12 col-sm-12 col-md-12">
        <div class="form-group">
            <strong>Content:</strong>
            {{ ucfirst($product->name) }}
        </div>
    </div>
    <div class="col-xs-12 col-sm-12 col-md-12">
        <div class="form-group">
            <strong>Cost Price:</strong>
            £{{ $product->cost_price }}
        </div>
    </div>
        <div class="col-xs-12 col-sm-12 col-md-12">
        <div class="form-group">
            <strong>Sale Price:</strong>
            £{{ $product->cost_price }}
        </div>
    </div>
        <div class="col-xs-12 col-sm-12 col-md-12">
        <div class="form-group">
            <strong>Status:</strong>
            @if($product->status == 1)
            Enabled
            @else
            Disabled
            @endif
        </div>
    </div>
            </div>
        </div>
    </div>
</div>
</div>
@endsection